% phi.m  
% save this in a file called  phi.m
% first line of code has to look like this...
function y=phi(x)

y=(1/sqrt(2*pi))*exp(-.5*x.^2);
% at the end, you have to compute y--
% see first line of code

